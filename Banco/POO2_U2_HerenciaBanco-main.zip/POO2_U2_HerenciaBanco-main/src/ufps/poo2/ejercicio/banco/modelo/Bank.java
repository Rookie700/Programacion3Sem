package ufps.poo2.ejercicio.banco.modelo;

public class Bank {

}
